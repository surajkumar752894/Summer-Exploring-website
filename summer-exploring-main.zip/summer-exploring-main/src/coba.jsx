export default function Coba() {
  return (
    <div className="grid place-items-center mt-8">
      <ul className="flex gap-4 text-4xl font-bold mobile:flex-col">
        <li>avhira</li>
        <li>ruican</li>
        <li>alice</li>
      </ul>
    </div>
  );
}
